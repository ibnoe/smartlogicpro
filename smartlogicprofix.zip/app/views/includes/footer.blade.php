<!-- start bagian footer -->
<footer>
		<div class="content">   
			<div class="box">2014 © Smart Logic Pro. Tous droits réservés.</div>
			<div class="box"><strong>Find me on: </strong>
				<a href="http://www.smartlogicpro.com">Website</a> / <a href="http://www.facebook.com/slpro">Facebook</a> / <a href="http://www.twitter.com/@smartlogicpro">Twitter</a>
				<br><br><strong>Phone:</strong> +62.274. 488 272 
				<strong>Email:</strong> info@smartlogicpro.com
			</div>
		</div>
</footer>	
<!-- end bagian footer -->	