<script>
  var url_login = "{{ route('login') }}";
  var url_foto  = "{{ asset('foto') }}";
</script>