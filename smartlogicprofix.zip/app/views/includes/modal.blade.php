<!-- .modal -->
<div class="modal fade" id="konfirmasi" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">

  <!-- .modal-dialog -->
  <div class="modal-dialog">

    <!-- .modal-content -->
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">
          Konfirmasi Hapus <span class="modal-objek"></span>
        </h4>
      </div>

      <div class="modal-body">
        Apakah anda yakin ingin menghapus data <span class="modal-objek"></span> dengan kode  <strong id="modal-kode"></strong>?
      </div>

      <div class="modal-footer">
        <button class="btn btn-primary" id="yes">Ya</button>
        <button class="btn btn-default" id="no" data-dismiss="modal">Tidak</button>
      </div>

    </div>
    <!-- .modal-content -->

  </div>
  <!-- /.modal-dialog -->

</div>
<!-- /.modal

<!-- .modal -->
<div class="modal fade" id="modal-foto" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">

  <!-- .modal-dialog -->
  <div class="modal-dialog">

    <!-- .modal-content -->
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">Foto <span id="nama-foto"></span></h4>
      </div>

      <div class="modal-body text-center">
        <img src="" alt="" class="img-responsive img-thumbnail" id="img-foto">
      </div>

      <div class="modal-footer">
        <button class="btn btn-default" id="no" data-dismiss="modal">Tutup</button>
      </div>

    </div>
    <!-- .modal-content -->

  </div>
  <!-- /.modal-dialog -->

</div>
<!-- /.modal