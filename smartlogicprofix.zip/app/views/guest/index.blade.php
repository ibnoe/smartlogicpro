@section('asset')
    @include('layouts.partials.datatable')
@stop

@section('content')
 
   <div id="box_dasar">

   </div>
   
@stop