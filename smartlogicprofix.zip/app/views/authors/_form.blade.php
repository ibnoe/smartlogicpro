<div class="uk-form-row">
    {{ Form::labelUk('name', 'Nama Penulis') }}
    {{ Form::textUk('name', 'Nama Penulis', 'uk-icon-user') }}
</div>
{{ HTML::divider() }}
<div class="uk-form-row">
    {{ Form::submitUk('Simpan') }}
</div>