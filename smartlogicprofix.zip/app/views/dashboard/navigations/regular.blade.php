{{ HTML::smartNav(route('dashboard'), 'Dashboard')}}
{{ HTML::smartNav(route('member.books'), 'Buku')}}
{{ HTML::smartNav(route('member.profile'), 'Profil')}}