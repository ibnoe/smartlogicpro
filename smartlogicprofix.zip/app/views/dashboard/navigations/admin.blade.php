{{ HTML::smartNav(route('dashboard'), 'Dashboard')}}
{{ HTML::smartNav(route('admin.books.index'), 'Buku')}}
{{ HTML::smartNav(route('admin.authors.index'), 'Penulis')}}
{{ HTML::smartNav(route('admin.users.index'), 'Member')}}
{{ HTML::smartNav(route('admin.borrow'), 'Peminjaman')}}