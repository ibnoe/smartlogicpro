<link rel="stylesheet" href="{{ asset('packages/datatables/css/jquery.dataTables.css')}}" />
<script src="{{ asset('packages/datatables/js/jquery.dataTables.js')}}"></script>