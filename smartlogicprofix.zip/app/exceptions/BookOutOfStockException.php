<?php

class BookOutOfStockException extends BookException { }