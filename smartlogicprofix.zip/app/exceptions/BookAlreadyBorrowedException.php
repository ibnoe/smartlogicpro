<?php

class BookAlreadyBorrowedException extends BookException { }