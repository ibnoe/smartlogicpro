<?php

class BookException extends Exception {}