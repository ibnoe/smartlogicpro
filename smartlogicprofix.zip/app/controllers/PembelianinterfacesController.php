<?php

class PembelianinterfacesController extends \BaseController {

	/**
	 * Display a listing of pembelian interface
	 *
	 * @return Response
	 */
	public function index()
	{
		
        return View::make('interfacepembelian.index');
	}
 


}
