<?php

class PenjualansController extends \BaseController {

	/**
	 * Display a listing of inteface penjualan
	 *
	 * @return Response
	 */
	public function index()
	{
		
        return View::make('interface.index');
	}
 


}
